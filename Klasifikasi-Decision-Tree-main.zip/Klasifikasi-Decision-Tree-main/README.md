# Klasifikasi-Decision-Tree
Nama : M. Azka Khoirul Ibad NIM: A11.2021.13517
